var __wpo = {
  "assets": {
    "main": [
      "/react-feh/favicon.ico",
      "/react-feh/runtime.8b101f41303bf6654316.js",
      "/react-feh/main~1f20a385.d19bfd4569aa5c66a0f7.chunk.js.LICENSE",
      "/react-feh/main~34c09fc5.602e9c5c5a7ac5a1362d.chunk.js.LICENSE",
      "/react-feh/main~53127b40.fb27225c4bedbd58885d.chunk.js.LICENSE",
      "/react-feh/main~ec3cbe50.edd65f16b0b4ac5a6b0a.chunk.js.LICENSE",
      "/react-feh/main~f9ca8911.50483892fcb21b97b380.chunk.js.LICENSE",
      "/react-feh/"
    ],
    "additional": [
      "/react-feh/npm.fbjs~34b28092.30ebedb59de3b7ce16d7.chunk.js",
      "/react-feh/npm.intl~24d9cf12.791f65a5f7fbbbb0f7b2.chunk.js",
      "/react-feh/npm.intl~b53bbd80.67190a6047d93c04a075.chunk.js",
      "/react-feh/npm.lodash~2930ad93.197d9485fb6c5cf59b97.chunk.js",
      "/react-feh/npm.react-lazyload~1481cd46.a675684f24f1dc0c1777.chunk.js",
      "/react-feh/npm.recompose~bd9cc342.1283e8127b03e5ba70d9.chunk.js",
      "/react-feh/main~09594eac.505f32b2bed2ff3c0d42.chunk.js",
      "/react-feh/main~16c59945.602f53d4355c32cc566f.chunk.js",
      "/react-feh/main~1f20a385.d19bfd4569aa5c66a0f7.chunk.js",
      "/react-feh/main~34c09fc5.602e9c5c5a7ac5a1362d.chunk.js",
      "/react-feh/main~3f764be9.72e835881a6ab70ac227.chunk.js",
      "/react-feh/main~53127b40.fb27225c4bedbd58885d.chunk.js",
      "/react-feh/main~678f84af.8f139699625151a81d89.chunk.js",
      "/react-feh/main~748942c6.0b994547c7463be53d26.chunk.js",
      "/react-feh/main~ec3cbe50.edd65f16b0b4ac5a6b0a.chunk.js",
      "/react-feh/main~ec8c427e.ca9f53a3fa7485154f96.chunk.js",
      "/react-feh/main~f9ca8911.50483892fcb21b97b380.chunk.js",
      "/react-feh/npm.babel~335b675d.7f5aa61d863786879aca.chunk.js",
      "/react-feh/npm.connected-react-router~ff255faf.ee0612db8ff7bb3e763e.chunk.js",
      "/react-feh/npm.core-js~020a9ba7.1d4359af7e534c4c6e21.chunk.js",
      "/react-feh/npm.core-js~21380ae4.40648b1a61b841ee4701.chunk.js",
      "/react-feh/npm.core-js~521a1f84.be862a21cf4fcf0382ec.chunk.js",
      "/react-feh/npm.core-js~5c956a7a.5041d653e3208cdbb501.chunk.js",
      "/react-feh/npm.core-js~789b3a00.4962d1535a150ba463dc.chunk.js",
      "/react-feh/npm.core-js~eefdb438.c51d8c8cec6c0fd3b14a.chunk.js",
      "/react-feh/npm.react-app-polyfill~516e31a0.64b4611fde2da13fb06c.chunk.js",
      "/react-feh/npm.react-redux~68a7743f.fd5b38debec0ada657f5.chunk.js",
      "/react-feh/npm.react-router-dom~d29cbfd9.2fee05b03c7ae5008537.chunk.js",
      "/react-feh/npm.react-router~c53b9a9d.0b74f51f19494aa05382.chunk.js",
      "/react-feh/npm.redux-saga~253ae210.713b2148753e9fb3c0bf.chunk.js",
      "/react-feh/31.5ab8e1ffcea998e6a673.chunk.js",
      "/react-feh/32.cc90c12a696b24087bba.chunk.js",
      "/react-feh/33.9fe0ed25256a4ca3f7b8.chunk.js",
      "/react-feh/34.8e4236d509121a97d3b6.chunk.js",
      "/react-feh/35.bdc693588c5e94803884.chunk.js",
      "/react-feh/36.4879ed2e844f6ddb9f9c.chunk.js",
      "/react-feh/37.5505cd7764e6b1405fe8.chunk.js",
      "/react-feh/38.534f875ffed88fd7d431.chunk.js",
      "/react-feh/39.5d11f3630ca0013c31d4.chunk.js",
      "/react-feh/40.28cb2a7a57d8ae788d38.chunk.js",
      "/react-feh/41.eccde3ed9fd1555edcaf.chunk.js",
      "/react-feh/42.32314d3da835495808a4.chunk.js",
      "/react-feh/43.477ca31a6fa2fe92c6e5.chunk.js",
      "/react-feh/44.a4b991346390cfeee7cb.chunk.js",
      "/react-feh/45.43b17b193edc61776baf.chunk.js",
      "/react-feh/46.886be666f02f755e8df1.chunk.js",
      "/react-feh/47.26b413bc9108ffe37bcf.chunk.js",
      "/react-feh/48.d06c34af137cd53ffb69.chunk.js",
      "/react-feh/49.bc3a9495bb5797129d1e.chunk.js",
      "/react-feh/50.d5a162548b3c8a3cbced.chunk.js",
      "/react-feh/51.6cc4b3b4847655515ef3.chunk.js",
      "/react-feh/52.b40e2b7f32be8712d218.chunk.js",
      "/react-feh/53.f6285b5e4be365e22ce0.chunk.js",
      "/react-feh/54.22a0ba96429d0791b0eb.chunk.js",
      "/react-feh/55.bea80a986f30615549cf.chunk.js",
      "/react-feh/56.bbab1b99fdaeae69e90f.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "06f375a97ddd695aefe3190ccc1ae9dac1b55121": "/react-feh/favicon.ico",
    "e3b6a4d13b1764204671649667bd8eec67a76a7b": "/react-feh/npm.fbjs~34b28092.30ebedb59de3b7ce16d7.chunk.js",
    "5abb32eecd04ac3197c20ebf8e183423af7607e1": "/react-feh/npm.intl~24d9cf12.791f65a5f7fbbbb0f7b2.chunk.js",
    "dec292d6c67ed31bea176bca9db525135d273762": "/react-feh/npm.intl~b53bbd80.67190a6047d93c04a075.chunk.js",
    "18aa6526b1793e27a245851f2d9394fce7467e7d": "/react-feh/npm.lodash~2930ad93.197d9485fb6c5cf59b97.chunk.js",
    "d25f27827444964c98c549cea93b90ef7c800353": "/react-feh/npm.react-lazyload~1481cd46.a675684f24f1dc0c1777.chunk.js",
    "96356f7406a0e32997fe828a71e3ba40976ee6d2": "/react-feh/npm.recompose~bd9cc342.1283e8127b03e5ba70d9.chunk.js",
    "8c22c6611198ea5887775c70721d67ae701fdbfb": "/react-feh/main~09594eac.505f32b2bed2ff3c0d42.chunk.js",
    "2256e80efd40f1651786898aeee95b40938ff5e2": "/react-feh/main~16c59945.602f53d4355c32cc566f.chunk.js",
    "d9a57680409e9205875925c505ecd9d4f9b11c6f": "/react-feh/main~1f20a385.d19bfd4569aa5c66a0f7.chunk.js",
    "91386ba102ec5c9475233e993f1be1fe514306fd": "/react-feh/main~34c09fc5.602e9c5c5a7ac5a1362d.chunk.js",
    "dc38d4eddbc608f4c47ae78a39141762a5f7bc8d": "/react-feh/main~3f764be9.72e835881a6ab70ac227.chunk.js",
    "67fb2daf7acc361506a67bd3032dcf13a8ff02db": "/react-feh/main~53127b40.fb27225c4bedbd58885d.chunk.js",
    "0158e284c16e33c491ef5dd9e92baaa1af60958d": "/react-feh/main~678f84af.8f139699625151a81d89.chunk.js",
    "b06dbde72ab3f3d0bcd77b0d0c626c246c1e3086": "/react-feh/main~748942c6.0b994547c7463be53d26.chunk.js",
    "596aa9bf57dc9bef0b0351de4794586890f5b160": "/react-feh/main~ec3cbe50.edd65f16b0b4ac5a6b0a.chunk.js",
    "a9ee31ff339e1d2f735acfaf874642091786e247": "/react-feh/main~ec8c427e.ca9f53a3fa7485154f96.chunk.js",
    "c878f073278925ae323ba379f42c06fd2936739d": "/react-feh/main~f9ca8911.50483892fcb21b97b380.chunk.js",
    "d02650e3d9145c16ccc532a7c718303a69bbaed2": "/react-feh/npm.babel~335b675d.7f5aa61d863786879aca.chunk.js",
    "120cf20fc7af788e3750b13b494cdd1541b78048": "/react-feh/npm.connected-react-router~ff255faf.ee0612db8ff7bb3e763e.chunk.js",
    "877c9038c698316c0f5370c1021c547c48ed1f8b": "/react-feh/npm.core-js~020a9ba7.1d4359af7e534c4c6e21.chunk.js",
    "bdd0bf0e198e71288e8f45beeeed1e86e763abfc": "/react-feh/npm.core-js~21380ae4.40648b1a61b841ee4701.chunk.js",
    "702f509ff85ec40e812950aa2f9eca86695b898d": "/react-feh/npm.core-js~521a1f84.be862a21cf4fcf0382ec.chunk.js",
    "9d42cec8a70af938463ff8830c025b263bdc232a": "/react-feh/npm.core-js~5c956a7a.5041d653e3208cdbb501.chunk.js",
    "36e6841874d2763c28e6325805b8089e7d3c568f": "/react-feh/npm.core-js~789b3a00.4962d1535a150ba463dc.chunk.js",
    "a8f9f9c186e054b9449b469b77c9163e9b9a21d8": "/react-feh/npm.core-js~eefdb438.c51d8c8cec6c0fd3b14a.chunk.js",
    "f0e718ba48b65be62a559a77bced43c85b8fed0e": "/react-feh/npm.react-app-polyfill~516e31a0.64b4611fde2da13fb06c.chunk.js",
    "2a0d82df23908099f908616ee21e5a1bb1fecfad": "/react-feh/npm.react-redux~68a7743f.fd5b38debec0ada657f5.chunk.js",
    "e97851b497e435879f85340cc9798fe0c01253e9": "/react-feh/npm.react-router-dom~d29cbfd9.2fee05b03c7ae5008537.chunk.js",
    "d7c75de14c6043329112f27f3888dc35c16e31e6": "/react-feh/npm.react-router~c53b9a9d.0b74f51f19494aa05382.chunk.js",
    "c2237c77901e6b49b2a433973c20bc154eaa1ad2": "/react-feh/npm.redux-saga~253ae210.713b2148753e9fb3c0bf.chunk.js",
    "4001d25fd1d6225679595cc8738318757d3ea1b2": "/react-feh/runtime.8b101f41303bf6654316.js",
    "7c7d0deb869c8d01176da0e832ce48c932c95b25": "/react-feh/31.5ab8e1ffcea998e6a673.chunk.js",
    "166106d379fb629aa41ccefc3df1712f2d167f05": "/react-feh/32.cc90c12a696b24087bba.chunk.js",
    "b73ed63da7842252af361f03a0b9bcece1b93bb7": "/react-feh/33.9fe0ed25256a4ca3f7b8.chunk.js",
    "4b0865f632fde35fb838c0613ed2e30f2a7cc015": "/react-feh/34.8e4236d509121a97d3b6.chunk.js",
    "60f73be951cdec4b927a15c8a13949a58aebc40b": "/react-feh/35.bdc693588c5e94803884.chunk.js",
    "ca2af35987e581e39f33da4c713b6e5e6bff3e7f": "/react-feh/36.4879ed2e844f6ddb9f9c.chunk.js",
    "21f2ecd625ece86f50952822e0ea290c7f732db9": "/react-feh/37.5505cd7764e6b1405fe8.chunk.js",
    "45fae41bb8c20b61f7ea850819fa6c3aa3a49455": "/react-feh/38.534f875ffed88fd7d431.chunk.js",
    "ab7a7fe452b850abfdab8cfebb46612e1e405de0": "/react-feh/39.5d11f3630ca0013c31d4.chunk.js",
    "fa772ef23c73fd122be1b68fbb432345bfbf2da9": "/react-feh/40.28cb2a7a57d8ae788d38.chunk.js",
    "94e7f08a5fd3fcb6a9dbe87ceaeed32234165976": "/react-feh/41.eccde3ed9fd1555edcaf.chunk.js",
    "2afc1e0b03e240ad40a1cadd890c30fa93967307": "/react-feh/42.32314d3da835495808a4.chunk.js",
    "63cd64afd3dbf41c763ade4463a420fe33fe143b": "/react-feh/43.477ca31a6fa2fe92c6e5.chunk.js",
    "a800d5212fc3946ed1fac7fb4f0d396c13750ea8": "/react-feh/44.a4b991346390cfeee7cb.chunk.js",
    "20bf8c3fe331f6f64908415b34fcd9f5c14f4db7": "/react-feh/45.43b17b193edc61776baf.chunk.js",
    "2ff7c24fce61c8504857fd3f08ab150a7948488b": "/react-feh/46.886be666f02f755e8df1.chunk.js",
    "a2fe76f8584117d5d792a3c97c36001835778b4e": "/react-feh/47.26b413bc9108ffe37bcf.chunk.js",
    "313d2880bc6a3226ec6460292b1e210a27cdc98f": "/react-feh/48.d06c34af137cd53ffb69.chunk.js",
    "44f5a804a7d71cdd877f6aa90aa680c602b9e7a2": "/react-feh/49.bc3a9495bb5797129d1e.chunk.js",
    "f019461646d740b7c6e9b12f2b9f9d942bdcd840": "/react-feh/50.d5a162548b3c8a3cbced.chunk.js",
    "a6d7417ea60747808ba53b20475b338b644e9ba9": "/react-feh/51.6cc4b3b4847655515ef3.chunk.js",
    "2e5201fddf1b597df9740302da33c40489d441b8": "/react-feh/52.b40e2b7f32be8712d218.chunk.js",
    "385a307dbabd57f99c228153e5f6ce34e0a74251": "/react-feh/53.f6285b5e4be365e22ce0.chunk.js",
    "c2409d109d4dfbf0ae02bdc3ed38f05116a25ee3": "/react-feh/54.22a0ba96429d0791b0eb.chunk.js",
    "d8802d9d0fabd3387f84c55e3cc4691493e75054": "/react-feh/55.bea80a986f30615549cf.chunk.js",
    "afac75d5dff21f90ec782c3ddb3c69f469fd9434": "/react-feh/56.bbab1b99fdaeae69e90f.chunk.js",
    "1a4d18f35e35e050e67acefc906827851484803b": "/react-feh/main~1f20a385.d19bfd4569aa5c66a0f7.chunk.js.LICENSE",
    "87bbe205da9941500ac914dc954b707ff5dbe470": "/react-feh/main~34c09fc5.602e9c5c5a7ac5a1362d.chunk.js.LICENSE",
    "7cc05a066dfe0964ce8f7ad7d788e5642537dc54": "/react-feh/main~53127b40.fb27225c4bedbd58885d.chunk.js.LICENSE",
    "346b0e2e9fcc06bdc91602dbc67827627d535ef0": "/react-feh/main~ec3cbe50.edd65f16b0b4ac5a6b0a.chunk.js.LICENSE",
    "5c82cea319e437891ccca019f55fa04fec171239": "/react-feh/main~f9ca8911.50483892fcb21b97b380.chunk.js.LICENSE",
    "1f091c82d5f022a5103b37bae734fa5d754070a9": "/react-feh/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "2020-5-9 1:18:53",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/react-feh/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "82d2cf37b83a21acd440");
/******/ })
/************************************************************************/
/******/ ({

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ }),

/***/ "82d2cf37b83a21acd440":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/react-feh/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ })

/******/ });