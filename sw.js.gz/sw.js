var __wpo = {
  "assets": {
    "main": [
      "/react-feh/favicon.ico",
      "/react-feh/runtime.ae7379d91acc746c8fc8.js",
      "/react-feh/main~1f20a385.be65af592c4a2ebf86b6.chunk.js.LICENSE.txt",
      "/react-feh/main~f9ca8911.9ab08baabad76f0dae2f.chunk.js.LICENSE.txt",
      "/react-feh/npm.react-dom~ab68c3a7.09a9c8038fcc4a78fc89.chunk.js.LICENSE.txt",
      "/react-feh/"
    ],
    "additional": [
      "/react-feh/npm.change-emitter~335e4a64.61dff7a13c84c0303211.chunk.js",
      "/react-feh/npm.intl~24d9cf12.1453135efce5c9c790ad.chunk.js",
      "/react-feh/npm.intl~b53bbd80.e007963abb92c7b95f32.chunk.js",
      "/react-feh/npm.lodash~2930ad93.e9c057a16546fa42cdb9.chunk.js",
      "/react-feh/npm.react-lazyload~1481cd46.10619a7ab9993ebe9271.chunk.js",
      "/react-feh/npm.recompose~bd9cc342.62057fef1c3c91203b37.chunk.js",
      "/react-feh/main~09594eac.912dde8c767dedee9f4c.chunk.js",
      "/react-feh/main~16c59945.69312d6282eb4d461fac.chunk.js",
      "/react-feh/main~1f20a385.be65af592c4a2ebf86b6.chunk.js",
      "/react-feh/main~3f764be9.ade8d4f4dbdf6f6374d6.chunk.js",
      "/react-feh/main~678f84af.bd2edbe2ebc2f0d440ef.chunk.js",
      "/react-feh/main~748942c6.f4c9c39e7e0d99437238.chunk.js",
      "/react-feh/main~ec8c427e.37585f92147d77161348.chunk.js",
      "/react-feh/main~f9ca8911.9ab08baabad76f0dae2f.chunk.js",
      "/react-feh/npm.babel~335b675d.a76fbe4831d54f571321.chunk.js",
      "/react-feh/npm.connected-react-router~ff255faf.087c5bce044d13df3fb2.chunk.js",
      "/react-feh/npm.core-js~020a9ba7.03bc1f328ea60bce448c.chunk.js",
      "/react-feh/npm.core-js~21380ae4.b334971f11ed500a8c27.chunk.js",
      "/react-feh/npm.core-js~521a1f84.2071b32bd691520635e2.chunk.js",
      "/react-feh/npm.core-js~5c956a7a.93b2dc5d5fb12722b826.chunk.js",
      "/react-feh/npm.core-js~789b3a00.c7ed4174d8ff2edf1e4b.chunk.js",
      "/react-feh/npm.core-js~eefdb438.ba3479305c334456c9a9.chunk.js",
      "/react-feh/npm.intl-messageformat~61b55d9a.51171b9ba97d5c9c2411.chunk.js",
      "/react-feh/npm.intl-relativeformat~d1299e8a.a54334a65b8021a6029e.chunk.js",
      "/react-feh/npm.react-app-polyfill~516e31a0.1447f35d905f38751764.chunk.js",
      "/react-feh/npm.react-dom~ab68c3a7.09a9c8038fcc4a78fc89.chunk.js",
      "/react-feh/npm.react-redux~c7a22eb1.e1e94f75808c6b94cc4d.chunk.js",
      "/react-feh/npm.redux-saga~253ae210.a4a560a023f94afe75b0.chunk.js",
      "/react-feh/29.bc221ad11363107fa48b.chunk.js",
      "/react-feh/30.d283fb2c2c8566dc3d5f.chunk.js",
      "/react-feh/31.6840eefb3b66f4a14abb.chunk.js",
      "/react-feh/32.60596e99b41ada43437d.chunk.js",
      "/react-feh/33.aec0286fef74d7408ca6.chunk.js",
      "/react-feh/34.650afc31f0c96a3e82dd.chunk.js",
      "/react-feh/35.9f057563e324896481cb.chunk.js",
      "/react-feh/36.5249150df4afc5247942.chunk.js",
      "/react-feh/37.e54e0b9dc049b2e69e87.chunk.js",
      "/react-feh/38.57cf5db55ee77b9ae3d5.chunk.js",
      "/react-feh/39.6491be19b26c7c1b3dc0.chunk.js",
      "/react-feh/40.2a93abefbfb71573a0ce.chunk.js",
      "/react-feh/41.5be9f07f4b2ca0131649.chunk.js",
      "/react-feh/42.1ed8bc67d94b37c71b1c.chunk.js",
      "/react-feh/43.ace439e1c14c59c98427.chunk.js",
      "/react-feh/44.3d746a3c5abb3866e75c.chunk.js",
      "/react-feh/45.9a60b3e3bb94ddf983a2.chunk.js",
      "/react-feh/46.77e631a645bf0fb1ed29.chunk.js",
      "/react-feh/47.d7a4ad58e83321558fbd.chunk.js",
      "/react-feh/48.630f62d2e7074eef439b.chunk.js",
      "/react-feh/49.3369a396857874a35da3.chunk.js",
      "/react-feh/50.147e171fe2021b38d171.chunk.js",
      "/react-feh/51.b94b1d72da14fbb4ab35.chunk.js",
      "/react-feh/52.1b90e98a5b0f99633093.chunk.js",
      "/react-feh/53.24df1f0b481b07173ac1.chunk.js",
      "/react-feh/54.617a5395324120ed29b3.chunk.js",
      "/react-feh/55.a0715a0fbbaad7bb2cad.chunk.js",
      "/react-feh/56.10eb52792096001aadff.chunk.js",
      "/react-feh/57.1bfac5f7ec5fb13634ba.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "06f375a97ddd695aefe3190ccc1ae9dac1b55121": "/react-feh/favicon.ico",
    "0c26774757ac293db05a204e8ef0ef41fbec82e3": "/react-feh/npm.change-emitter~335e4a64.61dff7a13c84c0303211.chunk.js",
    "5abb32eecd04ac3197c20ebf8e183423af7607e1": "/react-feh/npm.intl~24d9cf12.1453135efce5c9c790ad.chunk.js",
    "efba8cd23b6fb73fefabc0b7ded868ec04df92c4": "/react-feh/npm.intl~b53bbd80.e007963abb92c7b95f32.chunk.js",
    "190a4c1c8959b93bb8b88865b7fa7f3807c83b91": "/react-feh/npm.lodash~2930ad93.e9c057a16546fa42cdb9.chunk.js",
    "d25f27827444964c98c549cea93b90ef7c800353": "/react-feh/npm.react-lazyload~1481cd46.10619a7ab9993ebe9271.chunk.js",
    "96356f7406a0e32997fe828a71e3ba40976ee6d2": "/react-feh/npm.recompose~bd9cc342.62057fef1c3c91203b37.chunk.js",
    "6ca0f27aa60d5acd40d27b005a19045240554a10": "/react-feh/main~09594eac.912dde8c767dedee9f4c.chunk.js",
    "2256e80efd40f1651786898aeee95b40938ff5e2": "/react-feh/main~16c59945.69312d6282eb4d461fac.chunk.js",
    "45e5bce46bda1502d9d629e3e833beb56c6c06db": "/react-feh/main~1f20a385.be65af592c4a2ebf86b6.chunk.js",
    "8e893fb944d7b9ea956455fe80443c989f16a925": "/react-feh/main~3f764be9.ade8d4f4dbdf6f6374d6.chunk.js",
    "70bc8baccd612c9a7ee280bcd6ce180054927c31": "/react-feh/main~678f84af.bd2edbe2ebc2f0d440ef.chunk.js",
    "5b671b61b74fcdf91afb0959d85ed18848a4704c": "/react-feh/main~748942c6.f4c9c39e7e0d99437238.chunk.js",
    "292a4d640532870710d6b4b3548c9f17eb0b270f": "/react-feh/main~ec8c427e.37585f92147d77161348.chunk.js",
    "769f06c7145b161137222d6d50357228d74a5a14": "/react-feh/main~f9ca8911.9ab08baabad76f0dae2f.chunk.js",
    "73ab9570205ff265fffbd20f788a3e139335c511": "/react-feh/npm.babel~335b675d.a76fbe4831d54f571321.chunk.js",
    "325989a8b562a2b573b02ac5cd5386b405e97ac1": "/react-feh/npm.connected-react-router~ff255faf.087c5bce044d13df3fb2.chunk.js",
    "1ea12445d0eeeb17bb5d888e55adc3453c673620": "/react-feh/npm.core-js~020a9ba7.03bc1f328ea60bce448c.chunk.js",
    "dd35739a7007265bbe1adce186b74ab04e27da9f": "/react-feh/npm.core-js~21380ae4.b334971f11ed500a8c27.chunk.js",
    "7bfd7d1d2185a9d853adabd85c8a70d716379da4": "/react-feh/npm.core-js~521a1f84.2071b32bd691520635e2.chunk.js",
    "76b7e622aec017eb05baa70998d62d08b9782e75": "/react-feh/npm.core-js~5c956a7a.93b2dc5d5fb12722b826.chunk.js",
    "a678dccf0f5af04f0df99b8e27313f1c932817bc": "/react-feh/npm.core-js~789b3a00.c7ed4174d8ff2edf1e4b.chunk.js",
    "e9515ea32af5b492eff8445c041a4fa6acf46979": "/react-feh/npm.core-js~eefdb438.ba3479305c334456c9a9.chunk.js",
    "9772bfb3b331476639e9fdaa66bbc4fb7c8bdcb2": "/react-feh/npm.intl-messageformat~61b55d9a.51171b9ba97d5c9c2411.chunk.js",
    "e293f038b8d6b97a192ae4aa91a3a57674a09ee1": "/react-feh/npm.intl-relativeformat~d1299e8a.a54334a65b8021a6029e.chunk.js",
    "462dc823bdb0a1fe2acef8e0a084bc2e9039b419": "/react-feh/npm.react-app-polyfill~516e31a0.1447f35d905f38751764.chunk.js",
    "008e6f0714dba6cef93604726d7516c8b4440bc3": "/react-feh/npm.react-dom~ab68c3a7.09a9c8038fcc4a78fc89.chunk.js",
    "cc57b29eb5a7d7a9e68a99cf62cd1700f02be2f5": "/react-feh/npm.react-redux~c7a22eb1.e1e94f75808c6b94cc4d.chunk.js",
    "1b128054218f708bb919bb30917989a6ebc3d654": "/react-feh/npm.redux-saga~253ae210.a4a560a023f94afe75b0.chunk.js",
    "efb35404aebf63560cddd67a4853c41914f6f48d": "/react-feh/runtime.ae7379d91acc746c8fc8.js",
    "0eb35a28a130766ba19b4a1fa039ff2c42f93d68": "/react-feh/29.bc221ad11363107fa48b.chunk.js",
    "5973093eb6a9a430542627d48f24269c03dd37d6": "/react-feh/30.d283fb2c2c8566dc3d5f.chunk.js",
    "5c85a97d1bbbb020144ae354aa5fe2a19e438c0b": "/react-feh/31.6840eefb3b66f4a14abb.chunk.js",
    "e6a5108f000410163f46a3ad1ea36bb5055c0aae": "/react-feh/32.60596e99b41ada43437d.chunk.js",
    "8fa8d6777b56c21ccd43d368b1e0ad36ad5b98f8": "/react-feh/33.aec0286fef74d7408ca6.chunk.js",
    "a785fe7abf4ed5b3b2ecd02bdf38e54d8c1a465b": "/react-feh/34.650afc31f0c96a3e82dd.chunk.js",
    "fe7a50a69fb9290e4a516bdc1ea8009eb9b4d34f": "/react-feh/35.9f057563e324896481cb.chunk.js",
    "b5c54b02e101d5c04fbabbcfabc9c70b94eacb0f": "/react-feh/36.5249150df4afc5247942.chunk.js",
    "2428d2fabce690b6e80069648f92bf433bd45faa": "/react-feh/37.e54e0b9dc049b2e69e87.chunk.js",
    "6adbf56a9f723ff51ca23247d327a203782e7f5c": "/react-feh/38.57cf5db55ee77b9ae3d5.chunk.js",
    "3ff68e5b405af984a3a6f12fbff561d33c8d2fd8": "/react-feh/39.6491be19b26c7c1b3dc0.chunk.js",
    "7cab0792a8b6bf4f2889f39a58305c44b7a55dad": "/react-feh/40.2a93abefbfb71573a0ce.chunk.js",
    "9e49d1188d9b54cee8dfca629b3d2596993caaa7": "/react-feh/41.5be9f07f4b2ca0131649.chunk.js",
    "9244b429af1934e578df48fcddfa6791c366155b": "/react-feh/42.1ed8bc67d94b37c71b1c.chunk.js",
    "76d0cc26f2728f2a5a0d434dbda057183273b0f4": "/react-feh/43.ace439e1c14c59c98427.chunk.js",
    "1483afc2898cb075d963de39993bec5c10069427": "/react-feh/44.3d746a3c5abb3866e75c.chunk.js",
    "b2f723c4117888e87a33575bef79c61a86c50a3b": "/react-feh/45.9a60b3e3bb94ddf983a2.chunk.js",
    "2e4fae35da22b4c131a15f35e1c668120b755e61": "/react-feh/46.77e631a645bf0fb1ed29.chunk.js",
    "7019ddacbe3523d83a26469356fe164b24726de9": "/react-feh/47.d7a4ad58e83321558fbd.chunk.js",
    "b12ad25f3b16f27c0ffe93436b41d01f0f1583c4": "/react-feh/48.630f62d2e7074eef439b.chunk.js",
    "9f03b49ff7234d2a01a5722f94db19c768d06eb3": "/react-feh/49.3369a396857874a35da3.chunk.js",
    "e208b602aa72f9da8cf6dc58ec6adb3489cd5106": "/react-feh/50.147e171fe2021b38d171.chunk.js",
    "29956c395d2a057ff3e6b76b063d00c9c17ff48b": "/react-feh/51.b94b1d72da14fbb4ab35.chunk.js",
    "c308fa069d8b5b255b7e05add91f29c588e8a82c": "/react-feh/52.1b90e98a5b0f99633093.chunk.js",
    "bb39108ef137e0f0f5b4aea2d7493620bf6f167a": "/react-feh/53.24df1f0b481b07173ac1.chunk.js",
    "eec6c4345eb76d655d1a767ac2b05e4b3954f3cd": "/react-feh/54.617a5395324120ed29b3.chunk.js",
    "73ff007d5d39a5eba62e402b454b08e156df2cce": "/react-feh/55.a0715a0fbbaad7bb2cad.chunk.js",
    "87db79bdb8343f678ef002c00299b37f62022496": "/react-feh/56.10eb52792096001aadff.chunk.js",
    "4064f6952f17b8e441dfd53106305a8b05cfd117": "/react-feh/57.1bfac5f7ec5fb13634ba.chunk.js",
    "1a4d18f35e35e050e67acefc906827851484803b": "/react-feh/main~1f20a385.be65af592c4a2ebf86b6.chunk.js.LICENSE.txt",
    "27fa8a3788c9351e417e6db2d8723c90207797e5": "/react-feh/main~f9ca8911.9ab08baabad76f0dae2f.chunk.js.LICENSE.txt",
    "1486dce413b53a464963d193ac83bc2e6d57be78": "/react-feh/npm.react-dom~ab68c3a7.09a9c8038fcc4a78fc89.chunk.js.LICENSE.txt",
    "6af9ae682b999a4e21fa5044217a4803ad21b796": "/react-feh/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "2020-9-12 13:02:12",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/react-feh/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "82d2cf37b83a21acd440");
/******/ })
/************************************************************************/
/******/ ({

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ }),

/***/ "82d2cf37b83a21acd440":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/react-feh/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ })

/******/ });