var __wpo = {
  "assets": {
    "main": [
      "/react-feh/favicon.ico",
      "/react-feh/runtime.3a30d462fb4c4552035e.js",
      "/react-feh/main~1f20a385.aefc7f6e05530dea2d4a.chunk.js.LICENSE",
      "/react-feh/main~34c09fc5.c914a3a07aa504d08564.chunk.js.LICENSE",
      "/react-feh/main~53127b40.44f821b8b2de23274264.chunk.js.LICENSE",
      "/react-feh/main~ec3cbe50.8b14f852d087c492b748.chunk.js.LICENSE",
      "/react-feh/main~f9ca8911.e361033170618be8479d.chunk.js.LICENSE",
      "/react-feh/"
    ],
    "additional": [
      "/react-feh/npm.fbjs~34b28092.30ebedb59de3b7ce16d7.chunk.js",
      "/react-feh/npm.intl~24d9cf12.791f65a5f7fbbbb0f7b2.chunk.js",
      "/react-feh/npm.intl~b53bbd80.67190a6047d93c04a075.chunk.js",
      "/react-feh/index~05d9e4e6.0aba3f3fd32d16c2ff2f.chunk.js",
      "/react-feh/index~0cafb44a.3f06706631ad2058f437.chunk.js",
      "/react-feh/index~125cda43.0b1294f31bc481ea7b99.chunk.js",
      "/react-feh/index~17e9194c.5beafbe85a4c9fe1e61b.chunk.js",
      "/react-feh/index~19337cf8.16d81eb59974e16af75a.chunk.js",
      "/react-feh/index~1cbae1b3.fc2d6db6c2e97486c58a.chunk.js",
      "/react-feh/index~2200e1b0.cbfc90ac0f7e98c15d0f.chunk.js",
      "/react-feh/index~26d381a2.8d3e83d20fa3baf54560.chunk.js",
      "/react-feh/index~47bf76a8.78c0c3f35f9f3598fa7f.chunk.js",
      "/react-feh/index~4e91a974.cd88f02a88836e611ffc.chunk.js",
      "/react-feh/index~517933a1.69b7c58bf4532a479816.chunk.js",
      "/react-feh/index~55e1ec61.44866182bb275a2553f7.chunk.js",
      "/react-feh/index~8daca42e.c0e5db8962fb36e4af64.chunk.js",
      "/react-feh/index~8ec9a80f.eef12047746403f54959.chunk.js",
      "/react-feh/index~8ffdbd0e.3422968cbad3f3cdad2d.chunk.js",
      "/react-feh/index~92604409.4fac65cd98e20410164e.chunk.js",
      "/react-feh/index~9c777caf.3f4c41a79678260a4375.chunk.js",
      "/react-feh/index~a02ad34f.a69e6d927e6ee42e5446.chunk.js",
      "/react-feh/index~ae0dcf1f.df391346a7ab3f3c3bbd.chunk.js",
      "/react-feh/index~b7f95e54.1050b3b68ffa2a99a24e.chunk.js",
      "/react-feh/index~d939e436.39869557a080e8108a7b.chunk.js",
      "/react-feh/index~eb86cdd5.83f6c998ce9067f1dda2.chunk.js",
      "/react-feh/main~09594eac.4a0f5d122183c9c7723c.chunk.js",
      "/react-feh/main~16c59945.18d86d266860a3819ec8.chunk.js",
      "/react-feh/main~1f20a385.aefc7f6e05530dea2d4a.chunk.js",
      "/react-feh/main~34c09fc5.c914a3a07aa504d08564.chunk.js",
      "/react-feh/main~3f764be9.cdedb85fcc770a1fdc9c.chunk.js",
      "/react-feh/main~53127b40.44f821b8b2de23274264.chunk.js",
      "/react-feh/main~678f84af.66c1822533d7ce47ab15.chunk.js",
      "/react-feh/main~748942c6.30463ba1c4ad001cbeaf.chunk.js",
      "/react-feh/main~ec3cbe50.8b14f852d087c492b748.chunk.js",
      "/react-feh/main~ec8c427e.728e7de5715b80b82b39.chunk.js",
      "/react-feh/main~f9ca8911.e361033170618be8479d.chunk.js",
      "/react-feh/npm.babel~335b675d.e608057014296fd684a0.chunk.js",
      "/react-feh/npm.connected-react-router~ff255faf.38ba66566a54856ffc6e.chunk.js",
      "/react-feh/npm.core-js~020a9ba7.4bca6032cb23004749e9.chunk.js",
      "/react-feh/npm.core-js~21380ae4.60da65048869b6411783.chunk.js",
      "/react-feh/npm.core-js~521a1f84.5fa1ffece9d02e5e6370.chunk.js",
      "/react-feh/npm.core-js~5c956a7a.903c47bd9c12e36e53a0.chunk.js",
      "/react-feh/npm.core-js~789b3a00.6f625dbaeb80106e9acd.chunk.js",
      "/react-feh/npm.core-js~eefdb438.7d29512c29eaebc40ec2.chunk.js",
      "/react-feh/npm.lodash~2930ad93.6eacdd061e70f3cdb3b1.chunk.js",
      "/react-feh/npm.react-app-polyfill~516e31a0.1e3282d588b7dafbee36.chunk.js",
      "/react-feh/npm.react-lazyload~1481cd46.f296e798a66d8d561697.chunk.js",
      "/react-feh/npm.react-redux~68a7743f.d90ddb367ec1aad71afa.chunk.js",
      "/react-feh/npm.react-router-dom~d29cbfd9.278e4ea753b105e7bead.chunk.js",
      "/react-feh/npm.react-router~c53b9a9d.276cfed741b6fc98c0ae.chunk.js",
      "/react-feh/npm.recompose~bd9cc342.dbfeea0ac720fcc6407a.chunk.js",
      "/react-feh/npm.redux-saga~253ae210.30a8570c6c3637fa56bc.chunk.js",
      "/react-feh/53.a17ac5185938c52867e0.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "06f375a97ddd695aefe3190ccc1ae9dac1b55121": "/react-feh/favicon.ico",
    "e3b6a4d13b1764204671649667bd8eec67a76a7b": "/react-feh/npm.fbjs~34b28092.30ebedb59de3b7ce16d7.chunk.js",
    "5abb32eecd04ac3197c20ebf8e183423af7607e1": "/react-feh/npm.intl~24d9cf12.791f65a5f7fbbbb0f7b2.chunk.js",
    "dec292d6c67ed31bea176bca9db525135d273762": "/react-feh/npm.intl~b53bbd80.67190a6047d93c04a075.chunk.js",
    "a7bc76662736c711cb9130b1df816b8ea79c42fa": "/react-feh/index~05d9e4e6.0aba3f3fd32d16c2ff2f.chunk.js",
    "a778aa6522854a172aab3b6de929705fc28df2fe": "/react-feh/index~0cafb44a.3f06706631ad2058f437.chunk.js",
    "182109a643e9de66ae8ba3460e577284253774a3": "/react-feh/index~125cda43.0b1294f31bc481ea7b99.chunk.js",
    "363bc811d275382d4558ef12eb43b7042e1675ae": "/react-feh/index~17e9194c.5beafbe85a4c9fe1e61b.chunk.js",
    "965d15605a9c4f22a8e6bd890bb4c18ab57e3e96": "/react-feh/index~19337cf8.16d81eb59974e16af75a.chunk.js",
    "78e36f6e56f319045320b02d3fa078066c2e8970": "/react-feh/index~1cbae1b3.fc2d6db6c2e97486c58a.chunk.js",
    "ecb5be00f6f18e0f4cf3f4707f311c94a6dc98d2": "/react-feh/index~2200e1b0.cbfc90ac0f7e98c15d0f.chunk.js",
    "fc9c541d754217000df16ca6822fcb2c315a7515": "/react-feh/index~26d381a2.8d3e83d20fa3baf54560.chunk.js",
    "680bf87c58443a11653ff57222a6e2a2b0cc2c6e": "/react-feh/index~47bf76a8.78c0c3f35f9f3598fa7f.chunk.js",
    "fb20e46936866972529aee9ed11c938ae86e5ccc": "/react-feh/index~4e91a974.cd88f02a88836e611ffc.chunk.js",
    "6207512b1d7489e332faa8fb4518739912b2c1d2": "/react-feh/index~517933a1.69b7c58bf4532a479816.chunk.js",
    "6fbbe9054dd51181b60325a389cd08e1302b7aa9": "/react-feh/index~55e1ec61.44866182bb275a2553f7.chunk.js",
    "92fac110cf568151a170b0f3e74b7930643b1516": "/react-feh/index~8daca42e.c0e5db8962fb36e4af64.chunk.js",
    "9ba26ee17087fd36a5b0c719c852003525800428": "/react-feh/index~8ec9a80f.eef12047746403f54959.chunk.js",
    "705521783c2a8bc19ead8159e3bf043d2c02e38c": "/react-feh/index~8ffdbd0e.3422968cbad3f3cdad2d.chunk.js",
    "76538f3e2d1a3726e2a32f3d964c62cb05005b94": "/react-feh/index~92604409.4fac65cd98e20410164e.chunk.js",
    "e3d3429ca66abd9ed2ca21dbcbe9d83581d88277": "/react-feh/index~9c777caf.3f4c41a79678260a4375.chunk.js",
    "91366f74dd750f6674429f9af723a8069d23a823": "/react-feh/index~a02ad34f.a69e6d927e6ee42e5446.chunk.js",
    "4a2fbdfb13fe42b76c9b8dee74963cbeb627ce49": "/react-feh/index~ae0dcf1f.df391346a7ab3f3c3bbd.chunk.js",
    "dc6bd376ed2dcb7ca453b790b8cdea127150842e": "/react-feh/index~b7f95e54.1050b3b68ffa2a99a24e.chunk.js",
    "8f41679dd68a3a42fc82c2d3b8190e7c75d66cc2": "/react-feh/index~d939e436.39869557a080e8108a7b.chunk.js",
    "5b0cc8013bf214ddf679881de703517173db671d": "/react-feh/index~eb86cdd5.83f6c998ce9067f1dda2.chunk.js",
    "5ec14b75a4bbc5f07c99f447dc2b60a07705cc7d": "/react-feh/main~09594eac.4a0f5d122183c9c7723c.chunk.js",
    "d70fc1711c9729a65ea61a40fd0e25a969eaf595": "/react-feh/main~16c59945.18d86d266860a3819ec8.chunk.js",
    "8131a4071b7faac99aed4ebddf192eec57ed71d4": "/react-feh/main~1f20a385.aefc7f6e05530dea2d4a.chunk.js",
    "7cfb6b894e9bbc330b5acc49bbf7509e37ae30f1": "/react-feh/main~34c09fc5.c914a3a07aa504d08564.chunk.js",
    "246b1b78787d421838faf4f4d9671cf22de3338f": "/react-feh/main~3f764be9.cdedb85fcc770a1fdc9c.chunk.js",
    "4f351a901ee39bfa8b601c255ca992efe4b06639": "/react-feh/main~53127b40.44f821b8b2de23274264.chunk.js",
    "26a4be27addb32a49163309ffddb84be8e2907c5": "/react-feh/main~678f84af.66c1822533d7ce47ab15.chunk.js",
    "e07a0650155b1c9cfcf4f6734d95245edd3416b5": "/react-feh/main~748942c6.30463ba1c4ad001cbeaf.chunk.js",
    "9b992c73c8e7bfbad0c4a9490eda7f2479607269": "/react-feh/main~ec3cbe50.8b14f852d087c492b748.chunk.js",
    "5dddb51753b87edde217cfed65aaa335fb1350d1": "/react-feh/main~ec8c427e.728e7de5715b80b82b39.chunk.js",
    "84fdf4e5d661e1eec8f76752e19a4e81764cfda1": "/react-feh/main~f9ca8911.e361033170618be8479d.chunk.js",
    "7d7836c65c2ee833fd00cbde43096fe025b3f694": "/react-feh/npm.babel~335b675d.e608057014296fd684a0.chunk.js",
    "261e46fde7a824b7061b9f7bac17f4453057d77a": "/react-feh/npm.connected-react-router~ff255faf.38ba66566a54856ffc6e.chunk.js",
    "5824c0e5baae6a7ad49c12209a8e69d279155165": "/react-feh/npm.core-js~020a9ba7.4bca6032cb23004749e9.chunk.js",
    "0c97b9021a3e1ead1a66789635ff6f6b309b6a3b": "/react-feh/npm.core-js~21380ae4.60da65048869b6411783.chunk.js",
    "2d3b6948f4175fffb28044f4f6f330ff272038c7": "/react-feh/npm.core-js~521a1f84.5fa1ffece9d02e5e6370.chunk.js",
    "bbdef47d532ec1b8b315d2a8e3455cbc75ec786d": "/react-feh/npm.core-js~5c956a7a.903c47bd9c12e36e53a0.chunk.js",
    "8a43e3e91117db3417ab5fd03156b55ae8ddd706": "/react-feh/npm.core-js~789b3a00.6f625dbaeb80106e9acd.chunk.js",
    "9ad00b8d1eb2457ae1fd6ed764f1199f739679fb": "/react-feh/npm.core-js~eefdb438.7d29512c29eaebc40ec2.chunk.js",
    "7cdf6c03747bb98fa4ac4add09879f60aaf77c93": "/react-feh/npm.lodash~2930ad93.6eacdd061e70f3cdb3b1.chunk.js",
    "9236b836f3424956d27836e3a79dd5b19e55e601": "/react-feh/npm.react-app-polyfill~516e31a0.1e3282d588b7dafbee36.chunk.js",
    "fc93bc2c77bb5e751038629d74a5d6ee1f246c4c": "/react-feh/npm.react-lazyload~1481cd46.f296e798a66d8d561697.chunk.js",
    "0d26550e5accee4a51a324de25bfcae73ab3fe1f": "/react-feh/npm.react-redux~68a7743f.d90ddb367ec1aad71afa.chunk.js",
    "fcf7d55427693d1276d20f710a4895bef3079218": "/react-feh/npm.react-router-dom~d29cbfd9.278e4ea753b105e7bead.chunk.js",
    "dd3320431d87179b58927439ea6e605720042c0e": "/react-feh/npm.react-router~c53b9a9d.276cfed741b6fc98c0ae.chunk.js",
    "ea94c6c62012bf6051f44043bd157eebb905efac": "/react-feh/npm.recompose~bd9cc342.dbfeea0ac720fcc6407a.chunk.js",
    "ed041bd393c3869275a2cbbf3a11a32683d58164": "/react-feh/npm.redux-saga~253ae210.30a8570c6c3637fa56bc.chunk.js",
    "e72dc2758a8aaf6d3af52e5485ff2dc1700622fe": "/react-feh/runtime.3a30d462fb4c4552035e.js",
    "6b40272007033caaa289ceec9ea37ad151478a25": "/react-feh/53.a17ac5185938c52867e0.chunk.js",
    "1a4d18f35e35e050e67acefc906827851484803b": "/react-feh/main~1f20a385.aefc7f6e05530dea2d4a.chunk.js.LICENSE",
    "87bbe205da9941500ac914dc954b707ff5dbe470": "/react-feh/main~34c09fc5.c914a3a07aa504d08564.chunk.js.LICENSE",
    "7cc05a066dfe0964ce8f7ad7d788e5642537dc54": "/react-feh/main~53127b40.44f821b8b2de23274264.chunk.js.LICENSE",
    "346b0e2e9fcc06bdc91602dbc67827627d535ef0": "/react-feh/main~ec3cbe50.8b14f852d087c492b748.chunk.js.LICENSE",
    "5c82cea319e437891ccca019f55fa04fec171239": "/react-feh/main~f9ca8911.e361033170618be8479d.chunk.js.LICENSE",
    "0f5bafec9fc384d4a220cfc026dc88eb18e01724": "/react-feh/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "2020-4-11 13:44:44",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/react-feh/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "82d2cf37b83a21acd440");
/******/ })
/************************************************************************/
/******/ ({

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ }),

/***/ "82d2cf37b83a21acd440":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/react-feh/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ })

/******/ });