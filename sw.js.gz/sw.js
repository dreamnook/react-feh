var __wpo = {
  "assets": {
    "main": [
      "/react-feh/favicon.ico",
      "/react-feh/runtime.a9ec7eca5f15ca7851ca.js",
      "/react-feh/main~2a42e354.3aed45341f91af244ffc.chunk.js.LICENSE.txt",
      "/react-feh/main~f9ca8911.1aff870e2d54db631ebf.chunk.js.LICENSE.txt",
      "/react-feh/npm.react-dom~ab68c3a7.0f139b2914cfc36992b1.chunk.js.LICENSE.txt",
      "/react-feh/"
    ],
    "additional": [
      "/react-feh/npm.babel~335b675d.e6947258d724f89bd127.chunk.js",
      "/react-feh/npm.webpack~bf81ad4b.e7c0bdcc5b1c3bddebc6.chunk.js",
      "/react-feh/npm.lodash~2930ad93.3ef653d5686e087c7f71.chunk.js",
      "/react-feh/npm.react-lazyload~1481cd46.2e2a0639ed594dbda961.chunk.js",
      "/react-feh/main~09594eac.6233fb9663b594ffc9ac.chunk.js",
      "/react-feh/main~1c3a2c3f.92fa2ba2b5a4ab364604.chunk.js",
      "/react-feh/main~2a42e354.3aed45341f91af244ffc.chunk.js",
      "/react-feh/main~786da41e.e68e1083f2a3c224ad8f.chunk.js",
      "/react-feh/main~af74684e.9a07feaa59d4ce74a0b1.chunk.js",
      "/react-feh/main~f9ca8911.1aff870e2d54db631ebf.chunk.js",
      "/react-feh/npm.core-js~020a9ba7.6326afb213451da6b75e.chunk.js",
      "/react-feh/npm.core-js~21380ae4.a8a151a43e9626f47c1e.chunk.js",
      "/react-feh/npm.core-js~521a1f84.0639e62a6821c868f2df.chunk.js",
      "/react-feh/npm.core-js~5c956a7a.209193c8076d6b5bc898.chunk.js",
      "/react-feh/npm.core-js~789b3a00.32a6f0ab4c9e56642f42.chunk.js",
      "/react-feh/npm.core-js~eefdb438.69392adae79c7166491a.chunk.js",
      "/react-feh/npm.emotion~7a9eaa88.dccc39f429db0c28d92b.chunk.js",
      "/react-feh/npm.intl~9d7fa356.fd772f35545ef4e8f741.chunk.js",
      "/react-feh/npm.intl~b53bbd80.c7994cecf2d756807a3d.chunk.js",
      "/react-feh/npm.promise~0abeddcc.a976ee99b14a74d55908.chunk.js",
      "/react-feh/npm.react-app-polyfill~516e31a0.b5b3eac9229b1d37793a.chunk.js",
      "/react-feh/npm.react-dom~ab68c3a7.0f139b2914cfc36992b1.chunk.js",
      "/react-feh/npm.react-router-dom~d29cbfd9.2a82ddf125036377cf35.chunk.js",
      "/react-feh/npm.react-router~c53b9a9d.2bb3b0d14f3b025bfbe6.chunk.js",
      "/react-feh/25.bec89294520e862663fa.chunk.js",
      "/react-feh/26.77840f25574a79187142.chunk.js",
      "/react-feh/27.c0da705ef3267e2351d4.chunk.js",
      "/react-feh/28.dd36b8cf9616edd995c6.chunk.js",
      "/react-feh/29.04cfa7bc4eaf0419fd49.chunk.js",
      "/react-feh/30.ef587c52b3f3040bc66c.chunk.js",
      "/react-feh/31.1aeb99d37e6e8445b307.chunk.js",
      "/react-feh/32.d18f2e7f075d1a21e2c2.chunk.js",
      "/react-feh/33.907098683b2b307a4fbd.chunk.js",
      "/react-feh/34.89cc19703e776033b85d.chunk.js",
      "/react-feh/35.ce964acbe0d23d36e3a4.chunk.js",
      "/react-feh/36.d663efa3d4ff85b24bfe.chunk.js",
      "/react-feh/37.b0f8968d6fae66bd069f.chunk.js",
      "/react-feh/38.e22027a0dbe32eec52bb.chunk.js",
      "/react-feh/39.9d2803d792fb49080ea4.chunk.js",
      "/react-feh/40.476ab6b128a8959c88d6.chunk.js",
      "/react-feh/41.0a35da39b251ed496911.chunk.js",
      "/react-feh/42.02ef108ce405c845dc0c.chunk.js",
      "/react-feh/43.6201243112934852e19e.chunk.js",
      "/react-feh/44.bc6b66158393403fb709.chunk.js",
      "/react-feh/45.be73a705c9a8f5c9cba1.chunk.js",
      "/react-feh/46.7e3300431c5d94dd59e1.chunk.js",
      "/react-feh/47.3cc1285ef9f2ef8456fc.chunk.js",
      "/react-feh/48.7561d2f43d924cd383a5.chunk.js",
      "/react-feh/49.803212368eedb05825fb.chunk.js",
      "/react-feh/50.175b4c3ac78a43fa1a6a.chunk.js",
      "/react-feh/51.c8245116794b2a587649.chunk.js",
      "/react-feh/52.62be4fecfcb2f659ae94.chunk.js",
      "/react-feh/53.d04c8213ceff222b0969.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "06f375a97ddd695aefe3190ccc1ae9dac1b55121": "/react-feh/favicon.ico",
    "81060c748923936402277fdd0dfb8a605e8d0d9a": "/react-feh/npm.babel~335b675d.e6947258d724f89bd127.chunk.js",
    "2afcbe09d3ab3dd55192bae92d452a9b963feae7": "/react-feh/npm.webpack~bf81ad4b.e7c0bdcc5b1c3bddebc6.chunk.js",
    "64316fa31b38fc820c69448b5ff2548d158a6b17": "/react-feh/npm.lodash~2930ad93.3ef653d5686e087c7f71.chunk.js",
    "2a79957507fc9625cc11a35e9e4584ad5eb61507": "/react-feh/npm.react-lazyload~1481cd46.2e2a0639ed594dbda961.chunk.js",
    "b678b411546d53591a054e6ef6222848c5df4a99": "/react-feh/main~09594eac.6233fb9663b594ffc9ac.chunk.js",
    "3d38cfdc131c6a9ad608334e7770305ecaba1dfc": "/react-feh/main~1c3a2c3f.92fa2ba2b5a4ab364604.chunk.js",
    "7a274dfa07bc54ed70dd128994419358e512d604": "/react-feh/main~2a42e354.3aed45341f91af244ffc.chunk.js",
    "8f57813ca6f8f922ec68f87ee05a128c21f0b26f": "/react-feh/main~786da41e.e68e1083f2a3c224ad8f.chunk.js",
    "0949a0974beddb16237870c935e0ee336209966c": "/react-feh/main~af74684e.9a07feaa59d4ce74a0b1.chunk.js",
    "7e6727454bcc3303cabd60c95c0e8baa6a4a0a95": "/react-feh/main~f9ca8911.1aff870e2d54db631ebf.chunk.js",
    "3e4a0acebdce04d40166abc8bc1bf54effeb1a7c": "/react-feh/npm.core-js~020a9ba7.6326afb213451da6b75e.chunk.js",
    "9b6d8219496edaf5d4cddd3b7a3bcb59e7369266": "/react-feh/npm.core-js~21380ae4.a8a151a43e9626f47c1e.chunk.js",
    "15c683837afdfd7d0810b5bc75ea5ca425051a8e": "/react-feh/npm.core-js~521a1f84.0639e62a6821c868f2df.chunk.js",
    "a0f746648e91a9be92fd0ed0ce3462d53bb58090": "/react-feh/npm.core-js~5c956a7a.209193c8076d6b5bc898.chunk.js",
    "94ba899254a300e84857b2328252a78f1de12b10": "/react-feh/npm.core-js~789b3a00.32a6f0ab4c9e56642f42.chunk.js",
    "d5abc6f095e2f181ea14255514a84b1491a9e623": "/react-feh/npm.core-js~eefdb438.69392adae79c7166491a.chunk.js",
    "58fa6167b2d0de10d5bd57c141e1280a6e90e807": "/react-feh/npm.emotion~7a9eaa88.dccc39f429db0c28d92b.chunk.js",
    "0ca0f6bcfe9105b4e420e1fac80e2bd1621ed53a": "/react-feh/npm.intl~9d7fa356.fd772f35545ef4e8f741.chunk.js",
    "29d1e5a55ce777034406304c1de166e0179b3dd8": "/react-feh/npm.intl~b53bbd80.c7994cecf2d756807a3d.chunk.js",
    "5633cb6d331bee63a6ae1d59bfbcd6cef35a6303": "/react-feh/npm.promise~0abeddcc.a976ee99b14a74d55908.chunk.js",
    "4b0004e8b9d65c9ec2f32c8ab2098b6c912f7f14": "/react-feh/npm.react-app-polyfill~516e31a0.b5b3eac9229b1d37793a.chunk.js",
    "858e13882919a8f450decfa36a36a382fb1c2c24": "/react-feh/npm.react-dom~ab68c3a7.0f139b2914cfc36992b1.chunk.js",
    "27d7c64af6361f5bd06f5e8c1fd9eabbc4c94053": "/react-feh/npm.react-router-dom~d29cbfd9.2a82ddf125036377cf35.chunk.js",
    "d63fc0bcfec49fd011523c7b355ec29c93b9cff9": "/react-feh/npm.react-router~c53b9a9d.2bb3b0d14f3b025bfbe6.chunk.js",
    "dcb425f1e0afd9c0a42f7f168e7df62d05553b58": "/react-feh/runtime.a9ec7eca5f15ca7851ca.js",
    "bf391a13b5509efac339b77f227c94eb4cf53076": "/react-feh/25.bec89294520e862663fa.chunk.js",
    "d10880d4e03b405a096e3ce57428679ece03c46e": "/react-feh/26.77840f25574a79187142.chunk.js",
    "f061b573b599d77307cab4be7ac596babbc5848f": "/react-feh/27.c0da705ef3267e2351d4.chunk.js",
    "5c4af1e2ee0c7773a9a6c1a3958884e2714322e4": "/react-feh/28.dd36b8cf9616edd995c6.chunk.js",
    "90d6e6a6c0420b8551b50568fd4134b0682c8088": "/react-feh/29.04cfa7bc4eaf0419fd49.chunk.js",
    "25b97e054c19972ea8ddd387c2b73cd0df04cd2f": "/react-feh/30.ef587c52b3f3040bc66c.chunk.js",
    "f87096d5673ec406d5404204f753c753878cec14": "/react-feh/31.1aeb99d37e6e8445b307.chunk.js",
    "5f6e82f06eb667f06c977e5b8744b5c7f74a0366": "/react-feh/32.d18f2e7f075d1a21e2c2.chunk.js",
    "5d78ebd1370fdd79bd3937166928f42d4803e310": "/react-feh/33.907098683b2b307a4fbd.chunk.js",
    "58279f2e25cc002c2970ee07bec8c58186c82deb": "/react-feh/34.89cc19703e776033b85d.chunk.js",
    "78ff5b343d5e7a263d85634884feffc917fb4615": "/react-feh/35.ce964acbe0d23d36e3a4.chunk.js",
    "6e195c816ae0af5e4cc0faac548bb6f9684ae545": "/react-feh/36.d663efa3d4ff85b24bfe.chunk.js",
    "58702182544a37a63bbbccf017041216fbe737a4": "/react-feh/37.b0f8968d6fae66bd069f.chunk.js",
    "191ede32f077a407a41b03e9460447de2607a564": "/react-feh/38.e22027a0dbe32eec52bb.chunk.js",
    "bd6383a6ee2fadb9f48c0d382f9f3ace13d7d588": "/react-feh/39.9d2803d792fb49080ea4.chunk.js",
    "047edfc44ff794c680c3a673407ddd6cc93deec5": "/react-feh/40.476ab6b128a8959c88d6.chunk.js",
    "46b5991822aba3ff9f6036f389e2290308a9bf1c": "/react-feh/41.0a35da39b251ed496911.chunk.js",
    "5ba645545a3d02f0f1d001d0a90b8a963338f37b": "/react-feh/42.02ef108ce405c845dc0c.chunk.js",
    "f47e957f6e1720a9a790d3f20c651019497900c6": "/react-feh/43.6201243112934852e19e.chunk.js",
    "61264fb3ef85191d3b4bb286cae5efe7ffc0cb91": "/react-feh/44.bc6b66158393403fb709.chunk.js",
    "d5dda01b937e906fa29a7ad970b5a77edbefee19": "/react-feh/45.be73a705c9a8f5c9cba1.chunk.js",
    "83eafbe6632cbf0b0f91cb20279cbd0fdf107ba3": "/react-feh/46.7e3300431c5d94dd59e1.chunk.js",
    "124e92923c5ace5fba4664e07ae9340dbdf2f9aa": "/react-feh/47.3cc1285ef9f2ef8456fc.chunk.js",
    "1054b306ce6f336d8cf7c1dfab07f1000b23a117": "/react-feh/48.7561d2f43d924cd383a5.chunk.js",
    "37f27e4f1598643e461c4952b31fd9e0ab87876e": "/react-feh/49.803212368eedb05825fb.chunk.js",
    "ce818cafb14d8ebaa8c89a7621397cfd3be18a92": "/react-feh/50.175b4c3ac78a43fa1a6a.chunk.js",
    "e938ecc22193c594ed1d99d0985b5331e96a169a": "/react-feh/51.c8245116794b2a587649.chunk.js",
    "e13d9cd65ac329c224bda6c62d468c0f4f1e87b3": "/react-feh/52.62be4fecfcb2f659ae94.chunk.js",
    "7b1e753711467367b423fd819f397e712a4e44f6": "/react-feh/53.d04c8213ceff222b0969.chunk.js",
    "1a4d18f35e35e050e67acefc906827851484803b": "/react-feh/main~2a42e354.3aed45341f91af244ffc.chunk.js.LICENSE.txt",
    "d06e2252a2822f647fc5ff2e2f586cd113153deb": "/react-feh/main~f9ca8911.1aff870e2d54db631ebf.chunk.js.LICENSE.txt",
    "f3ff38eca00f970743a624309def1f1f4f6d56ce": "/react-feh/npm.react-dom~ab68c3a7.0f139b2914cfc36992b1.chunk.js.LICENSE.txt",
    "a3a4d6cb1509bca5c553b8bddfcc72eefce6caa2": "/react-feh/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "2020-10-9 21:11:14",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/react-feh/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "82d2cf37b83a21acd440");
/******/ })
/************************************************************************/
/******/ ({

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ }),

/***/ "82d2cf37b83a21acd440":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/react-feh/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ })

/******/ });