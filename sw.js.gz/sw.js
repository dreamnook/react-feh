var __wpo = {
  "assets": {
    "main": [
      "/react-feh/favicon.ico",
      "/react-feh/runtime.f9a28e1f5375e9964050.js",
      "/react-feh/main~1f20a385.ce865fa2eadd152ed8c0.chunk.js.LICENSE",
      "/react-feh/main~53127b40.23c1bd5bb194bea85c8a.chunk.js.LICENSE",
      "/react-feh/main~ec3cbe50.edd65f16b0b4ac5a6b0a.chunk.js.LICENSE",
      "/react-feh/main~f734b0c6.7c5a26f1b16cb3d1acad.chunk.js.LICENSE",
      "/react-feh/main~f9ca8911.04125cefa013472dfd84.chunk.js.LICENSE",
      "/react-feh/"
    ],
    "additional": [
      "/react-feh/npm.fbjs~34b28092.30ebedb59de3b7ce16d7.chunk.js",
      "/react-feh/npm.intl~24d9cf12.791f65a5f7fbbbb0f7b2.chunk.js",
      "/react-feh/npm.intl~b53bbd80.67190a6047d93c04a075.chunk.js",
      "/react-feh/npm.lodash~2930ad93.197d9485fb6c5cf59b97.chunk.js",
      "/react-feh/npm.react-lazyload~1481cd46.a675684f24f1dc0c1777.chunk.js",
      "/react-feh/npm.recompose~bd9cc342.1283e8127b03e5ba70d9.chunk.js",
      "/react-feh/main~09594eac.e448f2801ee8ab4eb7d0.chunk.js",
      "/react-feh/main~16c59945.602f53d4355c32cc566f.chunk.js",
      "/react-feh/main~1f20a385.ce865fa2eadd152ed8c0.chunk.js",
      "/react-feh/main~3f764be9.fea8b0d40027e14b326f.chunk.js",
      "/react-feh/main~53127b40.23c1bd5bb194bea85c8a.chunk.js",
      "/react-feh/main~66ada749.df1669f0ab5f9ef4377b.chunk.js",
      "/react-feh/main~678f84af.8f139699625151a81d89.chunk.js",
      "/react-feh/main~748942c6.0b994547c7463be53d26.chunk.js",
      "/react-feh/main~ec3cbe50.edd65f16b0b4ac5a6b0a.chunk.js",
      "/react-feh/main~ec8c427e.ca9f53a3fa7485154f96.chunk.js",
      "/react-feh/main~f734b0c6.7c5a26f1b16cb3d1acad.chunk.js",
      "/react-feh/main~f9ca8911.04125cefa013472dfd84.chunk.js",
      "/react-feh/npm.babel~335b675d.992998d0a047494774b7.chunk.js",
      "/react-feh/npm.connected-react-router~ff255faf.88a107037c1d5c4651a4.chunk.js",
      "/react-feh/npm.core-js~020a9ba7.4147e4ddd74de4fd5ada.chunk.js",
      "/react-feh/npm.core-js~21380ae4.b7588f9f448d1f64399c.chunk.js",
      "/react-feh/npm.core-js~521a1f84.b7b03ac807d64604bf64.chunk.js",
      "/react-feh/npm.core-js~5c956a7a.147184109c17987377cc.chunk.js",
      "/react-feh/npm.core-js~789b3a00.8d6f754e005c545d3214.chunk.js",
      "/react-feh/npm.core-js~eefdb438.934745547f1c3bfb3e78.chunk.js",
      "/react-feh/npm.intl-messageformat~61b55d9a.e5ef9b36d9a1f11e5183.chunk.js",
      "/react-feh/npm.intl-relativeformat~d1299e8a.08590e4a54290cee7fe2.chunk.js",
      "/react-feh/npm.react-app-polyfill~516e31a0.3236558361dc1a6ea466.chunk.js",
      "/react-feh/npm.react-redux~c7a22eb1.5479043f40b131371698.chunk.js",
      "/react-feh/npm.redux-saga~253ae210.6e1273e120bb1cd5f2d3.chunk.js",
      "/react-feh/32.3fc9d54091e0ed2137cf.chunk.js",
      "/react-feh/33.9db1b4939b6af3ec137e.chunk.js",
      "/react-feh/34.193a9e05e03d8362faf1.chunk.js",
      "/react-feh/35.3ac9c38eac50c030d892.chunk.js",
      "/react-feh/36.78822c98bed69f9243cd.chunk.js",
      "/react-feh/37.a3e66acd652f027d1521.chunk.js",
      "/react-feh/38.e1f3847c4e1035121b3c.chunk.js",
      "/react-feh/39.15e47bd7e8ecbc05fee7.chunk.js",
      "/react-feh/40.6d6fcce3436567f6cb93.chunk.js",
      "/react-feh/41.f0adf23fe6a53a9faccd.chunk.js",
      "/react-feh/42.89194042da36eee9139a.chunk.js",
      "/react-feh/43.b340f7a284f86aeff309.chunk.js",
      "/react-feh/44.6b37c7ed7580778b2812.chunk.js",
      "/react-feh/45.b214c89b58226cd65856.chunk.js",
      "/react-feh/46.a8f0162fb38a63ceca80.chunk.js",
      "/react-feh/47.405509efd2dc349acade.chunk.js",
      "/react-feh/48.502f84323eefb9abf863.chunk.js",
      "/react-feh/49.112681039b3c2ab0f649.chunk.js",
      "/react-feh/50.7e929b95f174069fae05.chunk.js",
      "/react-feh/51.72a7c7920a1257fc4339.chunk.js",
      "/react-feh/52.48670271e9ba807c3913.chunk.js",
      "/react-feh/53.99f5a600bf4fae7e8f02.chunk.js",
      "/react-feh/54.04d969ebc60969aa7f99.chunk.js",
      "/react-feh/55.b87c7dae8b55937d55ad.chunk.js",
      "/react-feh/56.8e8747a507731bb7126c.chunk.js",
      "/react-feh/57.2a04d3b29a97bb261b5e.chunk.js",
      "/react-feh/58.4e68a6405dcf7701fbc7.chunk.js",
      "/react-feh/59.13b2490dbc274a893736.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "06f375a97ddd695aefe3190ccc1ae9dac1b55121": "/react-feh/favicon.ico",
    "e3b6a4d13b1764204671649667bd8eec67a76a7b": "/react-feh/npm.fbjs~34b28092.30ebedb59de3b7ce16d7.chunk.js",
    "5abb32eecd04ac3197c20ebf8e183423af7607e1": "/react-feh/npm.intl~24d9cf12.791f65a5f7fbbbb0f7b2.chunk.js",
    "dec292d6c67ed31bea176bca9db525135d273762": "/react-feh/npm.intl~b53bbd80.67190a6047d93c04a075.chunk.js",
    "18aa6526b1793e27a245851f2d9394fce7467e7d": "/react-feh/npm.lodash~2930ad93.197d9485fb6c5cf59b97.chunk.js",
    "d25f27827444964c98c549cea93b90ef7c800353": "/react-feh/npm.react-lazyload~1481cd46.a675684f24f1dc0c1777.chunk.js",
    "96356f7406a0e32997fe828a71e3ba40976ee6d2": "/react-feh/npm.recompose~bd9cc342.1283e8127b03e5ba70d9.chunk.js",
    "0065b0d16ce0660fc9a1e806f48277b82adb9364": "/react-feh/main~09594eac.e448f2801ee8ab4eb7d0.chunk.js",
    "2256e80efd40f1651786898aeee95b40938ff5e2": "/react-feh/main~16c59945.602f53d4355c32cc566f.chunk.js",
    "135b3e6d61f1b26f893e4b8fd5b5c513fddc96c6": "/react-feh/main~1f20a385.ce865fa2eadd152ed8c0.chunk.js",
    "c3be187dc2b740854edaf5153a9f1bfbace1dc47": "/react-feh/main~3f764be9.fea8b0d40027e14b326f.chunk.js",
    "4e282342f4b8dcc996b8e3a4a8b590d55bb4aab9": "/react-feh/main~53127b40.23c1bd5bb194bea85c8a.chunk.js",
    "e758b615e7154604e27f29bb2b90cad74b30a3de": "/react-feh/main~66ada749.df1669f0ab5f9ef4377b.chunk.js",
    "0158e284c16e33c491ef5dd9e92baaa1af60958d": "/react-feh/main~678f84af.8f139699625151a81d89.chunk.js",
    "b06dbde72ab3f3d0bcd77b0d0c626c246c1e3086": "/react-feh/main~748942c6.0b994547c7463be53d26.chunk.js",
    "596aa9bf57dc9bef0b0351de4794586890f5b160": "/react-feh/main~ec3cbe50.edd65f16b0b4ac5a6b0a.chunk.js",
    "a9ee31ff339e1d2f735acfaf874642091786e247": "/react-feh/main~ec8c427e.ca9f53a3fa7485154f96.chunk.js",
    "4420f9870a856cadee69c43d892ef44bb3214475": "/react-feh/main~f734b0c6.7c5a26f1b16cb3d1acad.chunk.js",
    "8afdc20565e3a8b077d9d3fed995cb9f8f672105": "/react-feh/main~f9ca8911.04125cefa013472dfd84.chunk.js",
    "580348423ca15d5ee9ccefb79dd51f37dd928afd": "/react-feh/npm.babel~335b675d.992998d0a047494774b7.chunk.js",
    "d724cc19f01efd9ccc12b738833c5e5d0dfcfa0e": "/react-feh/npm.connected-react-router~ff255faf.88a107037c1d5c4651a4.chunk.js",
    "2b545bb5c99aa5e0622c3b423b2288a462cc8fef": "/react-feh/npm.core-js~020a9ba7.4147e4ddd74de4fd5ada.chunk.js",
    "be85a2f59d00f38a814d912036f5cdea579ab8d1": "/react-feh/npm.core-js~21380ae4.b7588f9f448d1f64399c.chunk.js",
    "0c5f5d762f3c971d83c6ccefc7491a8be4550cc8": "/react-feh/npm.core-js~521a1f84.b7b03ac807d64604bf64.chunk.js",
    "4380d2e00c14c74f71deae7417423a343c397ca3": "/react-feh/npm.core-js~5c956a7a.147184109c17987377cc.chunk.js",
    "8c86019b210e5851ed15150910fd8ad5664f7ec5": "/react-feh/npm.core-js~789b3a00.8d6f754e005c545d3214.chunk.js",
    "c3f2255c23eab8ffeb8d5dd6b7bce27597c30a78": "/react-feh/npm.core-js~eefdb438.934745547f1c3bfb3e78.chunk.js",
    "7e0f7ce40da8b2be201d0d03b92017d336b8258e": "/react-feh/npm.intl-messageformat~61b55d9a.e5ef9b36d9a1f11e5183.chunk.js",
    "74f1ad504797a2dafea5a95fe62fdbc43e6ae0e5": "/react-feh/npm.intl-relativeformat~d1299e8a.08590e4a54290cee7fe2.chunk.js",
    "ff6b867b8d3bb2d8fa21215d77f315cdf707315a": "/react-feh/npm.react-app-polyfill~516e31a0.3236558361dc1a6ea466.chunk.js",
    "cd1bd586be05766768e8f8438646c0aaf5e69c5c": "/react-feh/npm.react-redux~c7a22eb1.5479043f40b131371698.chunk.js",
    "dc626c8e854740ac8990a3aef1a5f940eda48671": "/react-feh/npm.redux-saga~253ae210.6e1273e120bb1cd5f2d3.chunk.js",
    "3ccb313db189a6488c81dacde4b6d98d6e8a5622": "/react-feh/runtime.f9a28e1f5375e9964050.js",
    "a36bc135f7db38e13e6edff5bb13e99d27a07c7b": "/react-feh/32.3fc9d54091e0ed2137cf.chunk.js",
    "6b62a0020a3659acccd2f5b8270e7c38a4497e7f": "/react-feh/33.9db1b4939b6af3ec137e.chunk.js",
    "1140434708b6d90be83b9a6ad29df7ccb3ec64da": "/react-feh/34.193a9e05e03d8362faf1.chunk.js",
    "8f00a910d3f9153d4dd0173629ed6de1f63e921d": "/react-feh/35.3ac9c38eac50c030d892.chunk.js",
    "c3ac9a7096ed2cfe85a91503b0e5a32a10d55a3c": "/react-feh/36.78822c98bed69f9243cd.chunk.js",
    "96541f2e7db3e6c84339ed75bd5a16359a1c65ca": "/react-feh/37.a3e66acd652f027d1521.chunk.js",
    "d31669536ae4ac2757418f5f43f755f190b2eb02": "/react-feh/38.e1f3847c4e1035121b3c.chunk.js",
    "8e9afb106b4b848cb2b3b8db17040a479f43aef0": "/react-feh/39.15e47bd7e8ecbc05fee7.chunk.js",
    "05d8e8d1ee48b8ada604f4d07f44dd32a5b94f56": "/react-feh/40.6d6fcce3436567f6cb93.chunk.js",
    "2be3f7df408c915eb55372b0f0de09f71d921df5": "/react-feh/41.f0adf23fe6a53a9faccd.chunk.js",
    "87e56c532653714605f74798463b8626d66ba5de": "/react-feh/42.89194042da36eee9139a.chunk.js",
    "66b0562a8177a9b7dcbae7ff3c68aa2a8d3bd947": "/react-feh/43.b340f7a284f86aeff309.chunk.js",
    "a35d73d10d5b9b7443d3260c815c323608f3df3e": "/react-feh/44.6b37c7ed7580778b2812.chunk.js",
    "aa048cfeb1e15c5bb295a9a0d2283d35f2ed4513": "/react-feh/45.b214c89b58226cd65856.chunk.js",
    "11e9c7480e4ec03c331b7fa7d96a0fe9cc13526a": "/react-feh/46.a8f0162fb38a63ceca80.chunk.js",
    "6e09017dcb996225ac6309c48bc0601544f8f8f2": "/react-feh/47.405509efd2dc349acade.chunk.js",
    "3c0136df5345b40fc6cdf27cde3af457c65083d7": "/react-feh/48.502f84323eefb9abf863.chunk.js",
    "3ae9b42633632278d44a32e2df05ba861f289f7f": "/react-feh/49.112681039b3c2ab0f649.chunk.js",
    "009a040b5c0186c82c4a8855a8daff05d82efc4d": "/react-feh/50.7e929b95f174069fae05.chunk.js",
    "d9df7dba92c3228828f4a7b635ea8515d1d0ec38": "/react-feh/51.72a7c7920a1257fc4339.chunk.js",
    "ac61c22fe9753892b3c2036766e90d0ded13b1e6": "/react-feh/52.48670271e9ba807c3913.chunk.js",
    "e77963491bbdd5979073b90274bfeab075339ba1": "/react-feh/53.99f5a600bf4fae7e8f02.chunk.js",
    "e7567aa528b6302e5dc9daa79661131912aecbcd": "/react-feh/54.04d969ebc60969aa7f99.chunk.js",
    "88ea6548746b5acfe5b7a5f2e7929a22106c318b": "/react-feh/55.b87c7dae8b55937d55ad.chunk.js",
    "d34db7529b579db79dd86c00512680503b1b13bf": "/react-feh/56.8e8747a507731bb7126c.chunk.js",
    "fe8b2d21fbef9f53f9e55772a17bf64132934cfc": "/react-feh/57.2a04d3b29a97bb261b5e.chunk.js",
    "4427a688cc66b98c88ccec4956e3a316b1f26430": "/react-feh/58.4e68a6405dcf7701fbc7.chunk.js",
    "064730ff5890ff51131a2e7e24d2f0150d14157f": "/react-feh/59.13b2490dbc274a893736.chunk.js",
    "1a4d18f35e35e050e67acefc906827851484803b": "/react-feh/main~1f20a385.ce865fa2eadd152ed8c0.chunk.js.LICENSE",
    "7cc05a066dfe0964ce8f7ad7d788e5642537dc54": "/react-feh/main~53127b40.23c1bd5bb194bea85c8a.chunk.js.LICENSE",
    "346b0e2e9fcc06bdc91602dbc67827627d535ef0": "/react-feh/main~ec3cbe50.edd65f16b0b4ac5a6b0a.chunk.js.LICENSE",
    "87bbe205da9941500ac914dc954b707ff5dbe470": "/react-feh/main~f734b0c6.7c5a26f1b16cb3d1acad.chunk.js.LICENSE",
    "5c82cea319e437891ccca019f55fa04fec171239": "/react-feh/main~f9ca8911.04125cefa013472dfd84.chunk.js.LICENSE",
    "9ff491f68eb8a6d8eece92ea7cce78cc874caf78": "/react-feh/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "2020-8-1 8:11:18",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/react-feh/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "82d2cf37b83a21acd440");
/******/ })
/************************************************************************/
/******/ ({

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ }),

/***/ "82d2cf37b83a21acd440":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/react-feh/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ })

/******/ });